<?php

$img_path="./view/upload/";
$img_path_cart="../upload/";


?>

